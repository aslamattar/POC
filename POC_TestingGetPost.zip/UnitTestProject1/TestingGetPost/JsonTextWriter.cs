﻿using System.IO;

namespace UnitTestProject1
{
    internal class JsonTextWriter
    {
        public JsonTextWriter(StreamWriter file)
        {
        }
    }
}