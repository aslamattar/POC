﻿using System;
using System.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestSharp;


namespace TestingGetPost
{
    [TestClass]
    public class FirstTest
    {
        IRestResponse response = null;
        IRestResponse response1 = null;
        private string serviceurl = "https://dev.shopatron.com";

        public RestRequest PrepareRequest(Method method, String authKey)
        {
            RestRequest restRequest = new RestRequest(method);
            restRequest.AddHeader("accept", "application/json");
            restRequest.AddHeader("content-type", "application/json");
            restRequest.AddHeader("authorization", "Bearer " + authKey);
            restRequest.AddHeader("API-Key", "stgadminkeyforqa");

            return restRequest;
        }

        [TestMethod]
        public void Auth()
        {
            RestRequest restRequest = new RestRequest(Method.POST);
            String textString= "grant_type = client_credentials";
            string resturl = "https://authstaging.cloudatron.com/oauthserver/oauth2/token";
            restRequest.AddHeader("content-type", "application/x-www-form-urlencoded");
            restRequest.AddHeader("Authorization", "Basic c3RnYWRtaW5rZXlmb3JxYTo0NWZjZDNiNGVlZmQ0MTI0YmRkNzZlMTFhNGVkZDZkYQ==");
            restRequest.AddParameter("application/json", textString, ParameterType.RequestBody);
            RestClient restclient = new RestClient(resturl);
            response1 = restclient.Execute(restRequest);
            Console.WriteLine(response1);
            Assert.AreEqual(ResponseStatus.Completed, response1.ResponseStatus);
        }

        [TestMethod]
        public void TestPostMethod()
        {
            String jsonString = "{\n \"externalOrderID\": \"Test_BC_{{$randomInt}}_{{$timestamp}}\",\n    \"manufacturerID\": 15569,\n    \"catalogID\": 19,\n    \"locale\": \"en-US\",\n    \"currency\": \"USD\",\n    \"customer\": {\n        \"customerID\": null,\n        \"firstName\": \"Jordan-Test\",\n        \"lastName\": \"Customer{{$randomInt}}\",\n        \"email\": \"QA_Test123@kibocommerce.com\",\n        \"password\": null,\n        \"phone1\": \"852-658-4578x1232\",\n        \"phone2\": \"8885552142\",\n        \"accountCreated\": null\n    },\n    \"orderItems\": [\n        {\n            \"product\": {\n                \"productID\": null,\n                \"partNumber\": \"LoadTestingPart1\",\n                \"SKU\": \"LoadTestingPart1\",\n                \"UPC\": \"LoadTestingPart1\",\n                \"name\": \"Part 1\",\n                \"retailPrice\": 50,\n                \"offerPrice\": null,\n                \"averageDealerMargin\": null,\n                \"availability\": \"Y\",\n                \"certLevel\": null,\n                \"imageUrl\": \"http://store.dolcegabbana.com/dw/image/v2/AAGA_PRD/on/demandware.static/-/Sites-15/default/dwbc41aa8e/images/zoom/BM1440AG031_HN610_0.jpg?sw=1571&sh=2000&sm=fit\"\n            },\n            \"itemSpecifics\": {\n                \"itemSpecificsID\": null,\n                \"externalItemID\": null,\n                \"actualPrice\": 1,\n                \"quantity\": 1,\n                \"shipping\": 1,\n                \"shippingTax\": null,\n                \"shippingTaxRate\": null,\n                \"giftCardInfo\": null,\n                \"itemTaxOverride\": null,\n                \"itemTaxRateOverride\": null,\n                \"customItemData\": null,\n                \"serialNumberRequired\": null,\n                \"expectedDeliveryDate\": null,\n                \"orderItemUnits\": null,\n                \"discounts\": [\n                    {\n                        \"code\": null,\n                        \"singleUseCode\": null,\n                        \"description\": \"Test Promotion\",\n                        \"amount\": 0,\n                        \"type\": \"PROMO2TEST\"\n                    }\n                ]\n            }\n        }\n    ],\n    \"orderPayments\": [\n        {\n            \"paymentMethod\": {\n                \"billingAddress\": {\n                    \"addressID\": null,\n                    \"customerID\": null,\n                    \"firstName\": null,\n                    \"lastName\": null,\n                    \"addressLine1\": \"123 TEST ORDER DRIVE\",\n                    \"addressLine2\": \"DO NOT SHIP\",\n                    \"addressLine3\": null,\n                    \"phone\": \"212-599-1770\",\n                    \"city\": \"New York\",\n                    \"state\": \"NY\",\n                    \"postalCode\": \"10016\",\n                    \"countryCode\": \"US\",\n                    \"fraudLock\": null,\n                    \"active\": null,\n                    \"latitude\": null,\n                    \"longitude\": null,\n                    \"company\": null,\n                    \"taxID\": null,\n                    \"isBilling\": null,\n                    \"isShipping\": null\n                },\n                \"paymentType\": \"CC\",\n                \"cardIssuer\": \"VI\",\n                \"cardNumber\": \"4111111111111111\",\n                \"cardExpiration\": \"09/2022\",\n                \"cardSecurityCode\": \"111\",\n                \"payPalToken\": null,\n                \"payPalPayerID\": null,\n                \"paymentMethodToken\": null,\n                \"authToken\": null,\n                \"ccLastFour\": null,\n                \"cardToken\": null,\n                \"creditPlan\": null,\n                \"creditPlanType\": null,\n                \"retailerRef\": null,\n                \"financeCode\": null,\n                \"paymentMethodID\": null\n            },\n            \"maxAmount\": 10,\n            \"transactionID\": null,\n            \"authorizationID\": null,\n            \"authAmount\": null,\n            \"orderPaymentID\": null\n        }\n    ],\n    \"orderGift\": null,\n    \"shippingMethod\": {\n        \"shippingType\": null,\n        \"shipType\": \"REGULAR\",\n        \"deliveryMethod\": \"SHIP_TO_HOME\",\n        \"name\": null,\n        \"description\": null,\n        \"price\": null,\n        \"failoverChoice\": null,\n        \"lookupZip\": null,\n        \"smsNumber\": null,\n        \"locationID\": null,\n        \"externalStoreID\": \"\",\n        \"pickupContact\": null\n    },\n    \"shippingAddress\": {\n        \"addressID\": null,\n        \"customerID\": null,\n        \"firstName\": null,\n        \"lastName\": null,\n        \"addressLine1\": \"123 TEST ORDER DRIVE\",\n        \"addressLine2\": \"DO NOT SHIP\",\n        \"addressLine3\": null,\n        \"phone\": \"212-599-1770\",\n        \"city\": \"New York\",\n        \"state\": \"NY\",\n        \"postalCode\": \"10016\",\n        \"countryCode\": \"US\",\n        \"fraudLock\": null,\n        \"active\": null,\n        \"latitude\": null,\n        \"longitude\": null,\n        \"company\": null,\n        \"taxID\": null,\n        \"isBilling\": null,\n        \"isShipping\": null\n    },\n    \"customerIP\": \"124.78.218.173\",\n    \"shippingTax\": null,\n    \"shippingTaxRate\": null,\n    \"forceItemTaxOverride\": false,\n    \"optInRetailer\": false,\n    \"customOrderData\": null,\n    \"allowSplit\": true,\n    \"isTestOrder\": true,\n    \"sendEmail\": true,\n    \"expectedDeliveryDate\": null,\n    \"discounts\": null,\n    \"channel\": null\n}";
            String resturl = serviceurl + "/api/v2/createOrder";
            RestClient restclient = new RestClient(resturl);
            /*OAuth expires in every 1 hr. You need to generate a new one before testing*/
            RestRequest restRequest = PrepareRequest(Method.POST, "fcffc3ea400449789102ccb5dd68caba");
            restRequest.AddParameter("application/json", jsonString, ParameterType.RequestBody);
            response = restclient.Execute(restRequest);
            /*Validate response content */
            Assert.AreEqual(ResponseStatus.Completed, response.ResponseStatus);
        }

        [TestMethod]
        public void TestGetMethod()
        {
            String resturl = serviceurl + "/api/v2/order/122837814";
            RestClient restclient = new RestClient(resturl);
            /*OAuth expires in every 1 hr. You need to generate a new one before testing*/
            RestRequest restRequest = PrepareRequest(Method.GET, "fcffc3ea400449789102ccb5dd68caba");
            response = restclient.Execute(restRequest);
          


            /*Validate response content */
           Assert.AreEqual(HttpStatusCode.OK, response.StatusCode, "Compare status code");
            //Assert.AreEqual(ResponseStatus.Completed, response.ResponseStatus);
        }

    }
}
